var swiper = new Swiper('.sect5__slider', {
  pagination: {
    el: '.sect5__pag',
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
  autoHeight: true,
  spaceBetween: 40
});
var swiper2 = new Swiper('.sect7__slider', {
  pagination: {
    el: '.sect7__pag',
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
  autoHeight: true,
  spaceBetween: 40
});
console.log('made by https://github.com/DanzigWebb')